import { Component,Injectable,Inject } from '@angular/core';
import { ActivatedRoute,Router, Params } from '@angular/router';
import {Employee} from 'src/addEmp/Employee'

@Component({
    template:`
	<div class="container">
	<table><tr>
	<td class="col-mg-4">
	<h1>You have registered Successfully! Please Login now! </h1>
	</td>
    <td class="col-mg-4">
	<img src="src/success/success.jpg"/>
	</td>
	</tr>
	</table>
	</div>
	<hr/>
	
    <button type="button" class="btn btn-primary" (click)='navigateToHome()'>Login Now</button>`
})


@Injectable()
export class SuccessComponent {
    constructor(@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
       
    }
    navigateToHome():void{
        this.router.navigate(['/home']);
    }
}
