import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable()
export class EmployeeService {
     getEmployee():Employee[]{
        return  [  
             { id: 101, name: 'Virat Kholi',desig:'TL' },    
             { id: 102, name: 'Yuvraj Singh',desig:'TL' },    
			 { id: 104, name: 'MS Dhoni',desig:'SSE' },    
			 { id: 109, name: 'Shikar Dhawan',desig:'TL' },   
			 { id: 121, name: 'Pujara',desig:'TL' },    
			 { id: 141, name: 'Ashwin R',desig:'SE' },    
			 { id: 155, name: 'Sachin Tendulkar',desig:'SE' },  
			 { id: 167, name: 'Suresh Raina',desig:'PM' }			 
           ]
    }
}