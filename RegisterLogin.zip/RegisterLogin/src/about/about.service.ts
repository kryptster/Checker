import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable()
export class AboutService {
     getEmployeeById():Employee{
	  e1:Employee ={id: 104, name: 'Ravan',desig:'SSE' };
		return e1;
    }
}