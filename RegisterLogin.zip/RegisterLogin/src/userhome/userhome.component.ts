import { Component,Injectable,Inject } from '@angular/core';
import { ActivatedRoute,Router, Params } from '@angular/router';

@Component({
    template:`
	<div class="container">
	<div>
		<blockquote>
			<p>
			You can have brilliant ideas, but if you can't get them across, your ideas won't get you anywhere.” These words of Lee Iacocca well summarize the need to communicate in the right manner, to the right people, at the right time and through the right channel. As we draw curtains on the celebrations of 100 Editions of the Talent India Highlights newsletter, let’s take a look at how Talent has been contributing to the success of our business over the years and the behind-the-scenes team which keeps the platform vibrant. Lastly, don’t forget to congratulate the Talent India Treasure Hunt winners!

			Promoting an honest culture
			In an organization like ours that brings together 100,000 employees in India, Internal Communications through various channels especially Talent, play an imperative role in fostering an open and honest culture. Arunkumar Gopalakrishnan_Talent
			Speaking on these lines Arunkumar Gopalakrishnan, Associate Vice President – HR enlists some key benefits that Talent has been providing to the HR function. According to him, “Talent serves as a platform where employees can access HR-related information such as employee handbook, safety manual, policies, forms, and benefit summaries. This central source offers an efficient and cost-effective way for HR departments to disseminate information—accurately and in a time bound manner—whether  it’s company policies, training topics, employee assistance programs, activities and events.”

			Backbone for business news. Our team members working across various service lines, practices and domains need to be aware about our business offerings and technology expertise. To this end, Talent hosts information about our clients, strategic business acquisitions, winning new deals, updates on ongoing engagements, successfully accomplished projects, initiatives to connect with our customers better, technology updates and so on. Featuring articles like successful deliveries/ roll-outs not only provide an overview of the project in a nutshell but also allow our worldwide colleagues to become aware about business operations in different countries and BUs.
			</p>
		</blockquote>
	</div>
	</div>
	<hr/>
	
    <button type="button" class="btn btn-primary" (click)='navigateToHome()'>Logout</button>`
})


@Injectable()
export class UserHomeComponent {
    constructor(@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
       
    }
    navigateToHome():void{
        this.router.navigate(['/home']);
    }
}
