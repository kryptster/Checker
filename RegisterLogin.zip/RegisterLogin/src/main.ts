import { Component, NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Routes, RouterModule }   from '@angular/router';
import { HomeComponent } from './home/home.component';
import { SuccessComponent } from './success/success.component';
import { RegisterComponent } from './register/register.component';
import { UserHomeComponent } from './userhome/userhome.component';
import { FormsModule } from '@angular/forms'

enableProdMode();

@Component({
  selector: 'my-app',
   templateUrl:'src/main.html'
})
export class AppComponent { 
}

const routes: Routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
	{ path: 'home',  component: HomeComponent }
	{ path: 'register',  component: RegisterComponent }
	{ path: 'success',  component: SuccessComponent }
	{ path: 'userhome',  component: UserHomeComponent }
];

@NgModule({
    imports:[ BrowserModule, RouterModule.forRoot(routes ,{ useHash: true }),FormsModule],
    declarations:[ AppComponent,HomeComponent,SuccessComponent,RegisterComponent,UserHomeComponent],
	//providers:[RegisterService],
    bootstrap:[ AppComponent ]
})
export class AppModule {
}
platformBrowserDynamic().bootstrapModule(AppModule);