#%%


import traceback
import Moving_Average
#import json

#%%

def run_analytic(data_json):
    """
    runs module
    Writes result in json file in 'Output' directory
    file_json_input : str, input json file name with path
    """

    try:
        #return 1
        tms_tmp = []
        dct_input = []
        parm_inp ={}
        tms_tmp = data_json['time-stamp']
        dct_input = data_json['data-point']
        parm_inp = data_json['parameters']
        print "==========================================================="
        resu = Moving_Average.main_prog(tms_tmp, dct_input, parm_inp)
        #resu = { "data": [tms_tmp] }
        print resu
        print "==========================================================="
        print repr(resu)
        print "==========================================================="
        return resu
        return 1

    except Exception, e:
        print('Error in run_analytic', str(e))
        traceback.print_exc()

