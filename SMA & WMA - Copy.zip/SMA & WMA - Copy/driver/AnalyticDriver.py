from analytics import run_analytic as ra
#import analytics as ra
#import run_analytic as ra

def mapper(*args, **kwargs):
    # decode args and kwargs
    try:        
        data = kwargs.pop('data')
        print "-----------data----------------"
        results = ra.run_analytic(data)
        print results
    except:
        print "Unexpected error ... "
        raise
    return results
