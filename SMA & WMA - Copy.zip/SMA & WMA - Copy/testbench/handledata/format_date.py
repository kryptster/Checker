# -*- coding: utf-8 -*-
"""
Created on Sat Aug 13 16:07:55 2016

@author: 302007850
"""
import traceback
import pandas as pd
# %%



# %%


def format_date(se_date, dt_format):
    """
    Converts date to ISO or epoch or specified string format.
    If the dt_format is None, the output format remains same as input

    se_date   : series, pandas input datetime of type 'string' or
                        'pd.tslib.Timestamp'
    dt_format : string, ouptut datetime format. It must be one of follwings 
                    None : same as input
                    iso  : (ISO 8601:'%Y-%m-%dT%H:%M:%S')
                    epoch: time in sec
                    '%Y-%m-%d %H:%M:%S' : python standard format types
                    'TIMESTAMP_FORMAT_OUT' = ISO (ISO 8601:'%Y-%m-%dT%H:%M:%S')
                                           = EPOCH (Unix time in sec)
                                           = None (same as input)
    se_date_out: series, string with output format
    """
    try:

        # ----------------------------------------
        # Constants/variables used in the program
        # ----------------------------------------
        iso_format = '%Y-%m-%dT%H:%M:%S'  # ISO 8601 format

        # ----------------------
        # Sort and format dates
        # ----------------------

        # if datetime is not pandas timpstamp(i.e str) convert to Timestamp
        if type(se_date[0]) != pd.tslib.Timestamp:
            se_date = pd.to_datetime(se_date)

        # Format date
        if bool(dt_format) == True:
            if dt_format.upper() == 'ISO':
                # se_date_out = se_date.strftime(iso_format)  # datetime index
                se_date_out = se_date.map(lambda t: t.strftime(iso_format))  # fore series
    
            elif dt_format.upper() == 'EPOCH':  # time in epoch sec
                se_date_out = se_date.astype(np.int64)/10**9 
                # se_date = pd.Series([time.mktime(t.timetuple()) for t in se_date])
    
            else: # specified string format
                # se_date_out =  se_date.strftime(dt_format)
                se_date_out = se_date.apply(lambda t: t.strftime(dt_format))
        else:
            se_date_out = se_date

        return se_date_out

    except Exception, e:
            print('Error in format_date', str(e))
            traceback.print_exc()