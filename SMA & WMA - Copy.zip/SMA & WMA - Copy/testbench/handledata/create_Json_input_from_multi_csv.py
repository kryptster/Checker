﻿
# %% IMPORT PACKAGES

import os
import traceback
import convert_csv2dict_for_json as c2dct
import json

# %%
fjson = r'..\data\predix_input_json\input.json'

fcsv_ipdata= r'C:\Users\anisroy\Documents\Myworkpace\anish\input1.csv'
fcsv_cnfg  = r'C:\Users\anisroy\Desktop\config\config_trend.csv'

# %%

def create_json_file(fcsv_ipdata):
    """
    Creates single json file by combining input and config files

    Parameters
    ------------
    fname_csv_ipdata : string, input data file name
    fname_csv_config : string, config file name
    
  return

    df_data         : dataframe,input data

    """

    try:
        # ------------------------------------------
        # Program constants 
        # ------------------------------------------

        fjson_input =fjson

        # -----------------------------------------------------------------
        # Convert each csv file to a dict compatible for json
        # -----------------------------------------------------------------

        if os.path.exists(fcsv_ipdata):
           dct_ipdata = c2dct.csv2dict(fcsv_ipdata)
        else:
            print 'Input data file does not exist---->' + fcsv_ipdata
        
       
        dct_cnfg={}
        if os.path.exists(fcsv_cnfg):
            dct_cnfg= c2dct.csv2dict(fcsv_cnfg)   
        else:
            print 'Config file does not exist---->' + fcsv_cnfg
        dct_cnfg= dict(zip(dct_cnfg['AlgorithmInputValueName'], dct_cnfg['Value']))    
        
       

        # ----------------------------------------------
        # Create dict data as required by predix format
        # -----------------------------------------------
        dct_input = {}
        dct_input['input_data'] = dct_ipdata
        dct_input['configurations'] = dct_cnfg
        dct_data = {}
        dct_data['data'] = dct_input
        
        # -----------------------------------------------------------------
        # Create single json file
        # -----------------------------------------------------------------
        # json_file = os.path.join(dir_input, json_fname_input)

        with open(fjson_input, 'w') as obj_json:
            json.dump(dct_data, obj_json, indent=4, sort_keys=False)

        print('\n\nJson file created successfully: ' + fjson_input)

        return fjson_input, dct_input

    except Exception, e:
            print('Error in creating json file from csv files', str(e))
            traceback.print_exc()

# ------------------------------------------------------------------------------

file_json_input, dct_input = create_json_file(fcsv_ipdata)
