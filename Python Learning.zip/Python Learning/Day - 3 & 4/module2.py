from  module3 import function2

def function1():
	print("Url : ",loc)
	__builtins__['loc'] = "www.cg.com"
	function2()