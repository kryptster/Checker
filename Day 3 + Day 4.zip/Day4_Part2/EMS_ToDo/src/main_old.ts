import { Component, NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Routes, RouterModule }   from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ViewEmployeeComponent } from './viewemp/emp.component';
import { EmployeeService } from './viewemp/employee.service';
import { EmpComponent } from './addemp/Employee.component';
import { SuccessComponent } from './success/success.component';
import { FormsModule } from '@angular/forms';


enableProdMode();

@Component({
  selector: 'my-app',
   templateUrl:'src/main.html'
})
export class AppComponent { 
}

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home',  component: HomeComponent },
  { path: 'addEmp',  component: EmpComponent },
   { path: 'viewEmp', component: ViewEmployeeComponent },
    { path: 'success', component: SuccessComponent },
	{ path: 'about/:id', component: AboutComponent }
];

@NgModule({
    imports:[ BrowserModule, RouterModule.forRoot(routes ,{ useHash: true }),FormsModule],
    declarations:[ AppComponent, HomeComponent, ViewEmployeeComponent,EmpComponent,AboutComponent,SuccessComponent],
	providers:[EmployeeService],
    bootstrap:[ AppComponent ]
})
export class AppModule {
}
platformBrowserDynamic().bootstrapModule(AppModule);