import {Component, NgModule} from '@angular/core'
import {BrowserModule} from '@angular/platform-browser'
import {Country } from './country';
 
@Component({
  selector: 'my-app',
  template: `
  <h1> Select a country </h1>
  <select (change)='setVal($event)'>
	  <option *ngFor="let country of countries" value= '{{country.id}}' >
		{{country.name}}
	  </option> 
	</select>
	The country id selected is {{val}}
  `
})
export class CountryListComponent {
  selectedCountry:Country = new Country(2, 'India');
  val:number="demo";
  countries = [
     new Country(1, 'USA' ),
     new Country(2, 'India' ),
     new Country(3, 'Australia' ),
     new Country(4, 'Brazil')
  ];
  setVal(e:any){
  alert("Here");
   this.val = event.target.value;
  }
}