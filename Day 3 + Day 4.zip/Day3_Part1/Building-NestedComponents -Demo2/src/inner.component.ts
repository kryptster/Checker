import {Component,Input} from '@angular/core';

@Component({
  selector: 'child-selector',
  template: `<h2>{{abcd}}</h2> `
  
})
export class ChildComponent {  
  @Input() abcd:string;
}

