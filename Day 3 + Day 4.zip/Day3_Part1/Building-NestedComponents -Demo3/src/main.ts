import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { ChildComponent } from './inner.component';
import { ParentComponent } from './outer.component';

enableProdMode();

@NgModule({
  imports:[ BrowserModule ],
  declarations:[ ParentComponent,ChildComponent ],
  bootstrap:[ ParentComponent ]
})
export class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);
  
