import { Component,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { CapitalizePipe } from './custom.pipe';

enableProdMode();

@Component({
    selector:'my-app',
    template:`<div>
        <h1>Custom Pipe</h1>
        <hr/>
        <h2>{{ name | capitalize }}</h2>
		<h2>{{ msg | capitalize }}</h2>
     </div>`
})
class CustomPipeComponent{
    name:string="capgemini global solutions";
	msg:string="WELCOME TO ANGULAR 2";
}
@NgModule({
    imports:[ BrowserModule ],
    declarations:[ CustomPipeComponent,CapitalizePipe ],
    bootstrap:[ CustomPipeComponent ]
})
class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);