// our parent component
import { Component,Input,OnInit,OnChanges,DoCheck,OnDestroy } from '@angular/core'
import {  AfterViewInit,AfterViewChecked,AfterContentInit,AfterContentChecked } from '@angular/core'
import { ChildComponent } from './child';

@Component({
  selector: 'my-parent',
  providers: [],
  template: `
    <div>
      <input type="text" #input />
      <input type="button" value="add" (click)="add(input.value); input.value = ''" />
    </div>
    <div>
      <ol>
        <my-child *ngFor="let log of logs; let i = index" [log]="log" [index]="i" (onDelete)="remove($event)"></my-child>
      </ol>
    </div>
  `,
  directives: [
    ChildComponent
  ]
})
export class ParentComponent implements OnInit, Onchanges, DoCheck, OnDestroy, AfterContentInit, AfterContentChecked, AfterViewinit, AfterViewChecked {
  
  @Input() data;
  logs = [];
  
  constructor() {
    this.logs.push('----- Initialized -----');
  }
  

  ngOnInit() {
    console.log(this.data);
    this.logs.push('ngOnInit');
  }
  
  ngOnChanges(changes) {
    console.log(changes);
    this.logs.push('ngOnChanges');
  }
  
  ngDoCheck() {
    this.logs.push('ngDoCheck');
  }
  
  ngAfterContentInit() {
    this.logs.push('ngAfterContentInit');
  }
  
  ngAfterContentChecked() {
    this.logs.push('ngAfterContentChecked');
  }

  ngAfterViewInit() {
    this.logs.push('ngAfterViewInit');
  }
  
  ngAfterViewChecked() {
    this.logs.push('ngAfterViewChecked');
  }
  
  ngOnDestroy() {
    this.logs.push('ngOnDestroy');
  }
  
  
  add(str) {
    this.logs.push(`----- input: "${str}" -----`);
  }
  
  remove(index) {
    this.logs.splice(index, 1);
  }
  
}