import {Component} from '@angular/core'
@Component({
    selector:'search-controls',
    template:'dstdsg'
})

export class SearchControlsComponent{

}