import { Component, Inject,NgModule } from '@angular/core';
import {EmployeeService} from './services/employeeService';
import {IEmployee} from './Models/IEmployee';
import {SearchControlsComponent} from './search.component'
import {ResultsDisplayComponent} from './resultsDisp.component'

@Component({
    selector:"directory",
    templateUrl:"src/templates/employeeDirectory.html",
    providers:[EmployeeService]
})
@NgModule({
    declarations : [SearchControlsComponent,ResultsDisplayComponent]
})
export class AppComponent{
    constructor(@Inject(EmployeeService) private EmpService:EmployeeService ){

    }
    searchkey:string;
    query:string;
    employees : IEmployee[] =this.EmpService.getEmployees();
   
    fetchEmployeesById(id:number):IEmployee[]{
       return this.EmpService.getEmployeeById(id);
    }
     fetchEmployeesByName(name:string):IEmployee[]{
       return this.EmpService.getEmployeeByName(name);
    }
    fetchAllEmployees():IEmployee[]{
        return this.EmpService.getEmployees();
    }
     
    onSubmit($event:any){
        $event.preventDefault();
        switch(this.searchkey){
        case "name" : {
                    this.employees = this.fetchEmployeesByName(this.query);
                    break;
                    }   
        case "id" : {
                    this.employees =  this.fetchEmployeesById(Number(this.query));
                    break;
                    };
        default :   { 
                    this.employees =  this.fetchAllEmployees();
                    }         
    };
    }
   
}