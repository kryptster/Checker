import {Component} from '@angular/core'
@Component({
    selector:'results',
    templateUrl:'src/templates/resultDisplayPort.html'
})

export class ResultsDisplayComponent{

}