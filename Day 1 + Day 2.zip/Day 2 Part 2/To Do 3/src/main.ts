import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';


enableProdMode();

@Component({
  selector: 'my-app',
  template: `<div>
	<h1>Enter a Number : </h1>
	<input type="select" (keyup)='onKey($event)'/>
	<hr/>
	<h1> The Number is {{result}}</h1>
  <div>`
})

export class EventObjectComponent {
	result:string="";
	values:number=0;
	onKey(event:any) {
		this.values = event.target.value%2;
		if this.values == 0 
			this.result = "Even";
		else if this.values == 1 
			this.result = "Odd";
		else
			this.result = 'Invalid';
	}
}

@NgModule({
	imports:[ BrowserModule ],
	declarations:[ EventObjectComponent ],
	bootstrap:[ EventObjectComponent ]
})
export class AppComponent{}

platformBrowserDynamic().bootstrapModule(AppComponent);