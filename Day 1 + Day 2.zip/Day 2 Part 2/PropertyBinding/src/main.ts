import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule }      from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

enableProdMode();

@Component({
  selector: 'my-app',
  template: `<div>
  <h1> Interpolation {{name}}</h1>
	<img [src]='photoUrl' title={{id}} alt="{{name+'.jpg'}}" [style.width.px]="100"/>
  <div>`
})

export class PropertyBindingComponent {
	id:number = 12232;
	name:string ="Kholi";
	photoUrl:string="images/hero.jpg";
	
}

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ PropertyBindingComponent ],
  bootstrap:    [ PropertyBindingComponent ]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);
  
  






  