import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic'
enableProdMode();

@Component({
  selector: 'my-app',
  template: `<div>
	<button (click)='fibonacci()'>Next Number</button>
	<div>
		<hr/>
		<h1>Fibonacci Series :{{m}}</h1>
	</div>
  <div>`
})

export class EventBindingComponent {
	//id:number = 123456;
	//name:string ="Kholi";
	//photoUrl:string="images/hero.jpg";
	m:string = '0';
	a:number = 1;
	b:number = 1;
	c:string =',';
	d:number = 0;
	fibonacci():number{
		this.m=this.m+this.c+this.a
		this.d=this.a+this.b;
		this.a=this.b;
		this.b=this.d;
		
	}
}

@NgModule({
	imports:[ BrowserModule ],
	declarations:[ EventBindingComponent ],
	bootstrap:[ EventBindingComponent ]
})
export class AppComponent{}

platformBrowserDynamic().bootstrapModule(AppComponent);

  