//app.component.ts - this is where we define our root component
import { Component } from '@angular/core'
@Component({
selector: 'my-app',
template: '<b>Bootstrapping an Angular Application</b>'
})
export class AppComponent { }


