#%%


import traceback
import WMA_Moving_Average
import json

#%%

def run_analytic(data_json):
    """
    runs module
    Writes result in json file in 'Output' directory
    file_json_input : str, input json file name with path
    """

    try:
        #return 1
        tmstmp_lst = data_json['TimeStamp']
        shaft_lst = data_json['Shaft']
        
        resu = WMA_Moving_Average.main_prog(tmstmp_lst, shaft_lst)
        #resu = { "data": [tmstmp_lst] }
        print resu
        #print "==========================================================="
        #print repr(resul)
        #print "==========================================================="
        return resu
        #return 1

    except Exception, e:
        print('Error in run_analytic', str(e))
        traceback.print_exc()

