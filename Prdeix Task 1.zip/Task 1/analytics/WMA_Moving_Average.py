# -*- coding: utf-8 -*-
"""
Created on Mon Dec 05 10:54:32 2016

@author: jpaulose
"""
import json

# %%

 
def main_prog(tmstmp_lst, dct_input):
        
        wt1 = .2
        wt2 = .3
        wt3 = .5
        resul1 = list()
        resul2 = list()
        cnt = len(dct_input) 
        for i in range(0,cnt):
            if i < 2:
               if i == 1:
                  Sha1 = dct_input[i-1] 
                  res2 = (dct_input[i] + Sha1) / 2
               else:
                  Sha1 = dct_input[i+2]
                  res2 = (dct_input[i] + Sha1) / 2
            else:
               Sha1 = dct_input[i-1]
               Sha2 = dct_input[i-2]
               res2 = (dct_input[i] + Sha1 + Sha2) / 3
            resul2.append(res2)
        
        for i in range(0,cnt):    
            if i < 2:
               if i == 1:
                  res1 = resul2[i] * wt3 + resul2[i-1] * wt2 
               else:
                  res1 = resul2[i] * wt3 + resul2[i+1] * wt2 
            else:
               res1 = resul2[i] * wt3 + resul2[i-1] * wt2 + resul2[i-2] * wt1
            resul1.append(res1)   

        #wma_res = ""
        sma_res = list()
        wma_res = list()
        
        sma_res2 = list()
        wma_res2 = list()
        ma_res2 = list()
        
        for i in range(0,cnt): 
            sma_res = list()
            wma_res = list()
            #print tmstmp_lst[i]
            #print dct_input[i]
            #if i > 0:
#                sma_res1.append(str(tmstmp_lst[i]))
#                sma_res =  sma_res + "," + "[" + str(tmstmp_lst[i]) + "," + str(resul2[i]) + "]"
            sma_res.append(tmstmp_lst[i])
            sma_res.append(resul2[i])
            # print "======================new1============="
                #print     sma_res            
            #    print "===================new2=================="
            sma_res2.append(sma_res)
            wma_res.append(tmstmp_lst[i])
            wma_res.append(resul1[i])
            #    print "======================new1============="
                #print     wma_res            
           #     print "===================new2=================="
            wma_res2.append(wma_res)
#                + "," + str(resul2[i]) + "]"

                #wma_res =  wma_res + "," + "[" + str(tmstmp_lst[i]) + "," + str(resul1[i]) + "]"
            #else:    
                #sma_res =  sma_res + "[" + str(tmstmp_lst[i]) + "," + str(resul2[i]) + "]"
            #    wma_res =  wma_res + "[" + str(tmstmp_lst[i]) + "," + str(resul1[i]) + "]"

        resul = {
            "data": { "SMA": {  
            "ingestor":"Thirumalai",
            "measurement":[
            sma_res2
            ]
            },
            "WMA": {  
            "ingestor":"Thirumalai",
            "measurement":[
		wma_res2
              ]
                  }
                  }
                  }
        a = dict(resul)
        #print "1==========================================================="
        #print sma_res2
        #print a
        #print json.JSONEncoder().encode(resul1)
        #return json.JSONEncoder().encode(resul1)
        #return resul          
        #print "2==========================================================="
        return json.dumps(a,sort_keys = 'true')
        #with open("json_file.json", "w") as json_file:
        #json.dump()
            
        #return json_file

        
