
# %% IMPORT PACKAGES
import os
import traceback
import json
import sys
#sys.path.append(r'../analytics') 
#sys.path.append(r'C:\Users\jpaulose\Desktop\Weighted Moving Average\Weighted Moving Average\analytics')
#import run_analytic as ra
from analytics import run_analytic as ra

# %%
# User input
file_json_input = r'C:\Users\jpaulose\Desktop\Weighted Moving Average\Weighted Moving Average\testbench\data\predix_input_json\input.json'
file_json_output = r'C:\Users\jpaulose\Desktop\Weighted Moving Average\Weighted Moving Average\testbench\data\output\output.json'
# %%


def predixtest_analytic(file_json_input,file_json_output):
    try:
        # 1. Read input json file & prepare data

        with open(file_json_input) as json_obj:
            dct_json_data = json.load(json_obj)
        
        dct_data = dct_json_data['data']
        dct_result =ra.run_analytic(dct_data)
        
      
        with open(file_json_output, 'w') as outfile:
           json.dump(dct_result, outfile)
        print '\nSuccessful, out file---> ' + os.path.abspath(file_json_output)

    except Exception, e:
        print('Error in test_analytic', str(e))
        traceback.print_exc()

# %%

if __name__ == "__main__":
        predixtest_analytic(file_json_input,file_json_output)



