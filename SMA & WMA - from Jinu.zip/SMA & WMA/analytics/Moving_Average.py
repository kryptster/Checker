# -*- coding: utf-8 -*-
"""
Created on Tuesday May 03 09:54:32 2017

@author: Velu/Pugazh/Rosh
"""
import json

# %%

 
def main_prog(tms_tmp, dct_input, parm_inp):
        
        wt1 = .2
        wt2 = .3
        wt3 = .5
        resul1 = list()
        resul2 = list()
        cnt = len(dct_input) 
	if parm_inp['technique'] == 'SMA' :
		for i in range(0,cnt):
			if i < 2:
				if i == 1:
					val1 = dct_input[i-1] 
					res1 = (dct_input[i] + val1) / 2
				else:
					val1 = dct_input[i+2]
					res1 = (dct_input[i] + val1) / 2
			else:
				val1 = dct_input[i-1]
				val2 = dct_input[i-2]
				res1 = (dct_input[i] + val1 + val2) / 3
			resul1.append(res1)
		
	elif parm_inp['technique'] == 'WMA' :
		for i in range(0,cnt):    
			if i < 2:
				if i == 1:
					res2 = dct_input[i] * wt3 + dct_input[i-1] * wt2 
				else:
					res2 = dct_input[i] * wt3 + dct_input[i+1] * wt2 
			else:
				res2 = dct_input[i] * wt3 + dct_input[i-1] * wt2 + dct_input[i-2] * wt1
			resul2.append(res2)   
	else:
		print('technique not defined')
			

        sma_res = list()
        wma_res = list()
        
        sma_res2 = list()
        wma_res2 = list()
        ma_res2 = list()
        
        for i in range(0,cnt): 
            sma_res = list()
            wma_res = list()
            sma_res.append(tms_tmp[i])
            sma_res.append(resul1[i])
            sma_res2.append(sma_res)
            wma_res.append(tms_tmp[i])
            wma_res.append(resul2[i])
            wma_res2.append(wma_res)

        resul = {
            "data": { "SMA": {  
            "ingestor":"Velu/Pugazh/Rosh",
            "measurement":[
            sma_res2
            ]
            },
            "WMA": {  
            "ingestor":"Velu/Pugazh/Rosh",
            "measurement":[
		wma_res2
              ]
                  }
                  }
                  }
        a = dict(resul)

        return json.dumps(a,sort_keys = 'true')


        
