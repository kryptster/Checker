# -*- coding: utf-8 -*-
"""

"""
# %% IMPORT PACKAGES

import os
import traceback
import pandas as pd
import json
import format_date as fd
import df2dict_for_json as d2d

# %%


# Csv files with relative directories

csv_file =r'..\data\input\inputdata.csv'  # \config\analytic_config.csv'  # input\267834_2015-10-01 120000.csv'
csv_file1 = r'..\data\input\predictdata.csv'  # \config\analytic_config.csv'  # input\267834_2015-10-01 120000.csv'
is_csv_file_timeseries = 0  # 0: non-time series data file, 1: time series data

# Assign json file dir and name
json_file = csv_file.replace('.csv', '.json')
json_file1 = csv_file1.replace('.csv', '.json')

# Specify date field and format for time series data
if is_csv_file_timeseries == 1:
    dt_field_csv = 'DateTime'  # 'DateTime'  # column name for input data
    dt_field_json = 'DateTime'  # 'DateTime'  # column name for predix input json
    dt_format_json = '%Y-%m-%d %H:%M:%S' #'iso' #'epoch' #'%Y-%m-%d %H:%M:%S', None, 
else:
    dt_field_csv = None  # column name for input data
    dt_field_json = None  # column name for predix input json
    dt_format_json = None #'iso' #'epoch' #'%Y-%m-%d %H:%M:%S', None, 

          
# %% 
            
       
def csv2json(csv_file, dt_field_csv, dt_field_out, dt_format_out, json_file):

        """
        converts '.csv' file (mainly OSM files) to dict compatible to json.
        If it contains time stamp data, the name must be 'DateTime'.

        Parameters
        ----------
        csv_file: string, csv file name with path (OSM filed data)
                   it must have 'DATE' & 'TIME' as two columns
        return :
        dct_data: dict, panda dictionary compatible for json
        """
        try:

            # --------------------------------------------------------
            # Read csv file to a data frame
            # --------------------------------------------------------
            # read data from each csv file
            obj_file = open(csv_file, 'r')

            # read header & identify if DateTime in single col or 2-cols
            hdr = obj_file.readline().replace('\n','')
            obj_file.close()

            hdr_split = hdr.split(',')

            # hdr_split_upr = map(lambda x: x.upper(), hdr_split)
            # Read data

            if (bool(dt_field_csv) == True) & (dt_field_csv in set(hdr_split)):

                if dt_field_csv == dt_field_out:
                    df_data = pd.read_csv(csv_file, parse_dates=[dt_field_csv])

                else:
                    df_data = pd.read_csv(csv_file,
                              parse_dates = {dt_field_out: dt_field_csv})

            if bool(dt_format_out) == True:                
                df_data[dt_field_out] = fd.format_date(df_data[dt_field_out],
                                                       dt_format_out)
                
            else:
                df_data = pd.read_csv(csv_file)

            # --------------------------------------------------------
            # Convert to dictionary for json
            # --------------------------------------------------------
            # dct_data = {}
            dct_data = d2d.df2dict(df_data)

#            # Key value pair if it is a config file
            if ('Name' in dct_data) & ('Value' in dct_data):
                dct_data = dict(zip(dct_data['Name'], dct_data['Value']))  # key value payer
    
            # Write json file
            if bool(json_file) == True:
                with open(json_file, 'w') as obj_json:
                    json.dump(dct_data, obj_json, indent=4, sort_keys=False)
    
                print('\n\nJson file created successfully: ' + json_file)
    
            return dct_data

        except Exception, e:
            print('Error in converting csv file to dict file', str(e))
            traceback.print_exc()


# %% 3. OUTPUT : Test

if __name__ == '__main__':
    dct_data = csv2json(csv_file,dt_field_csv, dt_field_json,
                          dt_format_json, json_file)
    dct_data1 = csv2json(csv_file1, dt_field_csv, dt_field_json,
                          dt_format_json, json_file1)
