# -*- coding: utf-8 -*-
"""
Created on Tue Aug 09 18:36:09 2016

@author: 302007850
"""
import os
import pandas as pd
import json


json_file = r'C:\Users\anisroy\Documents\Myworkpace\anish\testbench\data\output\output.json'

with open(json_file) as data_file:    
    dct_data = json.load(data_file)
    print"-------",dct_data
# for predix output json
df_data = pd.DataFrame.from_dict(dct_data['output'])

csv_file = json_file.replace('.json', '.csv')
df_data.to_csv(csv_file, index=False)
