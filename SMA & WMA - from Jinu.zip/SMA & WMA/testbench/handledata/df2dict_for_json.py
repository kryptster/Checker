# -*- coding: utf-8 -*-
"""
Created on Sat Aug 13 16:22:36 2016

@author: 302007850
"""
import pandas as pd
import collections as col


# %%

def df2dict(df_data):

    dct_data = col.OrderedDict()
    for field in df_data.columns:

        if df_data[field].dtype == 'int64':
            dct_data[str(field)] = [int(e) for e in df_data[field]]

        elif df_data[field].dtype == 'float64':
            dct_data[str(field)] = [float(e) for e in df_data[field]]

        elif df_data[field].dtype == 'bool':
            dct_data[str(field)] = [bool(e) for e in df_data[field]]

        else:
            dct_data[str(field)] = [str(e) for e in df_data[field]]

    return dct_data