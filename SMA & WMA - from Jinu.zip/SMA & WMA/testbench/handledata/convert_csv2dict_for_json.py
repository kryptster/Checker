# -*- coding: utf-8 -*-
"""
Created on Wed Jul 18 18:31:00 2016

"""
# %% IMPORT PACKAGES


import traceback
import pandas as pd
import collections as col


# %%  ALGORITHM


def csv2dict(csv_file):

        """
        converts '.csv' file (mainly OSM files) to dict compatible to json.

        Parameters
        ----------
        csv_file: string, csv file name with path (OSM filed data)
                   
        return :
        dct_data: dict, panda dictionary compatible for json
        """
        try:
            # --------------------------------------------------------
            # Read csv file to a data frame
            # --------------------------------------------------------
            df_data = pd.read_csv(csv_file)


            # --------------------------------------------------------
            # Convert to dictionary
            # --------------------------------------------------------
            
            dct_data = col.OrderedDict()

            for field in df_data.columns:

                if df_data[field].dtype == 'int64':
                    dct_data[str(field)] = list(df_data[field].astype(int))

                elif df_data[field].dtype == 'float64':
                    dct_data[str(field)] = list(df_data[field].astype(float))

                else:
                    dct_data[str(field)] = [str(x) for x in df_data[field]]

            return dct_data

        except Exception, e:
            print('Error in converting csv file to dict file', str(e))
            traceback.print_exc()



# %%  
